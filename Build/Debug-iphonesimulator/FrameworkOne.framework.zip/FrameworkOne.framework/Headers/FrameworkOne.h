//
//  FrameworkOne.h
//  FrameworkOne
//
//  Created by Matthew O'Leary on 10/04/2020.
//  Copyright © 2020 Matthew O'Leary. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for FrameworkOne.
FOUNDATION_EXPORT double FrameworkOneVersionNumber;

//! Project version string for FrameworkOne.
FOUNDATION_EXPORT const unsigned char FrameworkOneVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FrameworkOne/PublicHeader.h>


